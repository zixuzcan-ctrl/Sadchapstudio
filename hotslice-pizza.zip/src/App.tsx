import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';
import { 
  Headphones, Mic, Sliders, Video, Film, MapPin, Phone, Instagram, 
  Menu as MenuIcon, X, User, LogOut, ChevronRight, Play, Star, Calendar, Youtube, Facebook
} from 'lucide-react';
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth, signInWithGoogle, logOut, db, handleFirestoreError, OperationType } from './lib/firebase';
import { collection, doc, setDoc, serverTimestamp, query, orderBy, onSnapshot } from 'firebase/firestore';

interface ServiceItem {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  image: string;
}

const SERVICES: ServiceItem[] = [
  { id: 'recording', name: 'Recording', description: 'Crystal clear vocals with premium microphones and acoustically treated rooms.', icon: <Mic size={32} />, image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=800' },
  { id: 'beat', name: 'Beat Production', description: 'Custom beats tailored to your style. Trap, Hip-Hop, Pop, and R&B.', icon: <Headphones size={32} />, image: 'https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?q=80&w=800' },
  { id: 'mixing', name: 'Mixing & Mastering', description: 'Industry-standard mixing and mastering to make your track radio-ready.', icon: <Sliders size={32} />, image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=800' },
  { id: 'video_shoot', name: 'Video Shoot', description: 'Cinematic music video production with high-end 4K cameras & lighting.', icon: <Video size={32} />, image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?q=80&w=800' },
  { id: 'video_editing', name: 'Video Editing', description: 'Professional video editing with VFX, color grading, and dynamic cuts.', icon: <Film size={32} />, image: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?q=80&w=800' },
];

const TypewriterText = ({ text }: { text: string }) => {
  const [displayedText, setDisplayedText] = useState("");
  useEffect(() => {
    let index = 0;
    const interval = setInterval(() => {
      setDisplayedText(text.slice(0, index + 1));
      index++;
      if (index >= text.length) clearInterval(interval);
    }, 100);
    return () => clearInterval(interval);
  }, [text]);
  return <span>{displayedText}</span>;
};

export default function App() {
  const [loading, setLoading] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [isAdminView, setIsAdminView] = useState(false);
  const [adminAuthOpen, setAdminAuthOpen] = useState(false);
  const [adminPwd, setAdminPwd] = useState("");
  const [adminTab, setAdminTab] = useState("dashboard");
  const [themeColor, setThemeColor] = useState("#ff003c");
  const [user] = useAuthState(auth);
  const [bookings, setBookings] = useState<any[]>([]);

  // Form State
  const [bName, setBName] = useState("");
  const [bPhone, setBPhone] = useState("");
  const [bService, setBService] = useState(SERVICES[0].name);

  // Settings State
  const [studioName, setStudioName] = useState("Sadakchaap Studio");
  const [studioPhone, setStudioPhone] = useState("8383021468");
  const [socialInstagram, setSocialInstagram] = useState("https://instagram.com/sadakchaapstudio");
  const [socialYoutube, setSocialYoutube] = useState("https://youtube.com");
  const [socialFacebook, setSocialFacebook] = useState("https://facebook.com");

  const { scrollYProgress } = useScroll();
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.2], [1, 1.1]);

  useEffect(() => {
    document.documentElement.style.setProperty('--theme-color', themeColor);
  }, [themeColor]);

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPwd === "0000022220000") {
      setAdminAuthOpen(false);
      setIsAdminView(true);
      setAdminPwd("");
    } else {
      alert("Incorrect Password!");
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!user) {
      setBookings([]);
      return;
    }
    const q = query(collection(db, 'users', user.uid, 'orders'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snap) => {
      setBookings(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, error => {
      console.error(error);
    });
    return () => unsub();
  }, [user]);

  const handleBookSession = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
       alert("Please log in to book a session.");
       return;
    }
    try {
      const orderRef = doc(collection(db, 'users', user.uid, 'orders'));
      await setDoc(orderRef, {
        items: [{ name: bService, quantity: 1 }],
        totalPrice: 0, // Quote based
        status: 'pending',
        clientName: bName,
        clientPhone: bPhone,
        createdAt: serverTimestamp()
      });
      setIsBookingOpen(false);
      alert("Booking Request Sent! We will contact you soon.");
      
      // WhatsApp redirect if user wants to message direct
      const waMsg = `Hi Sadakchaap Studio, I'm ${bName}. I want to book a session for ${bService}.`;
      window.open(`https://wa.me/918383021468?text=${encodeURIComponent(waMsg)}`, '_blank');

    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/orders`);
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-brand-black flex flex-col items-center justify-center z-[100]">
        <motion.div
          animate={{ scale: [1, 1.2, 1], filter: ['drop-shadow(0 0 0px #ff003c)', 'drop-shadow(0 0 20px #ff003c)', 'drop-shadow(0 0 0px #ff003c)'] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="text-brand-red mb-6"
        >
          <Headphones size={80} strokeWidth={1} />
        </motion.div>
        <h1 className="font-display text-4xl tracking-widest text-white uppercase text-glow-red">
          Sadakchaap<br/>Studio
        </h1>
      </div>
    );
  }

  // --- ADMIN VIEW (Simulated Dashboard) ---
  if (isAdminView) {
    return (
      <div className="min-h-screen bg-brand-black text-white flex flex-col md:flex-row">
         {/* Sidebar */}
         <div className="w-full md:w-64 bg-brand-gray border-b md:border-b-0 md:border-r border-white/10 p-6 flex flex-col">
           <h1 className="font-display text-2xl font-bold text-glow-red mb-12 uppercase text-brand-red">Admin Panel</h1>
           <div className="space-y-4 flex-1">
             {['dashboard', 'services', 'gallery', 'settings'].map(tab => (
               <button 
                 key={tab} 
                 onClick={() => setAdminTab(tab)} 
                 className={`block w-full text-left uppercase tracking-widest text-sm font-bold p-3 rounded-lg transition-colors ${adminTab === tab ? 'bg-brand-red text-white' : 'text-white/50 hover:bg-white/5 hover:text-white'}`}
               >
                 {tab}
               </button>
             ))}
           </div>
           <button onClick={() => setIsAdminView(false)} className="mt-8 text-white/50 hover:text-brand-red flex items-center gap-2 text-sm font-bold uppercase tracking-widest transition-colors mb-4 md:mb-0">
             <LogOut size={16} /> Exit Admin
           </button>
         </div>
         
         {/* Main Content */}
         <div className="flex-1 p-6 md:p-12 overflow-y-auto max-h-screen">
            {adminTab === 'dashboard' && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <h2 className="font-display text-3xl mb-8 border-b border-white/10 pb-4">Overview</h2>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
                  {[{t: "Total Bookings", v: bookings.length.toString()}, {t: "Revenue", v: "₹1.4L"}, {t: "Visitors", v: "3.2K"}, {t: "Active Requests", v: bookings.filter(b => b.status === "pending").length.toString()}].map((stat, i) => (
                    <div key={i} className="bg-brand-gray p-6 rounded-xl border border-brand-red/20 shadow-[0_0_15px_var(--theme-color,rgba(255,0,60,0.1))]">
                      <p className="text-white/50 mb-2 uppercase tracking-widest text-xs">{stat.t}</p>
                      <h3 className="text-3xl font-display text-brand-red text-glow-red">{stat.v}</h3>
                    </div>
                  ))}
                </div>
            
                <h2 className="text-xl mb-6 border-b border-white/5 pb-2 inline-block">Client Requests</h2>
                <div className="bg-brand-gray rounded-xl overflow-x-auto border border-white/5">
                  <table className="w-full text-left min-w-[600px]">
                    <thead className="bg-black/50">
                      <tr>
                        <th className="p-4 text-white/50 tracking-widest text-sm uppercase">Client</th>
                        <th className="p-4 text-white/50 tracking-widest text-sm uppercase">Contact</th>
                        <th className="p-4 text-white/50 tracking-widest text-sm uppercase">Service</th>
                        <th className="p-4 text-white/50 tracking-widest text-sm uppercase">Status</th>
                        <th className="p-4 text-white/50 tracking-widest text-sm uppercase">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {bookings.map((b, i) => (
                        <tr key={i} className="border-t border-white/5">
                          <td className="p-4">{b.clientName || 'Unknown'}</td>
                          <td className="p-4 text-brand-red">{b.clientPhone || 'N/A'}</td>
                          <td className="p-4 text-white/80">{b.items?.[0]?.name || 'Custom'}</td>
                          <td className="p-4"><span className="bg-white/10 px-2 py-1 rounded text-xs uppercase">{b.status}</span></td>
                          <td className="p-4 flex gap-2">
                            <button className="text-brand-red text-xs font-bold border border-brand-red/50 px-3 py-1 rounded hover:bg-brand-red hover:text-white transition">Approve</button>
                            <button className="text-white/50 text-xs font-bold border border-white/20 px-3 py-1 rounded hover:bg-white/10 transition">Delete</button>
                          </td>
                        </tr>
                      ))}
                      {bookings.length === 0 && (
                        <tr>
                          <td colSpan={5} className="p-8 text-center text-white/50 italic">No bookings found.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}
            
            {adminTab === 'services' && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <h2 className="font-display text-3xl mb-8 flex justify-between items-center border-b border-white/10 pb-4">
                  Services & Plans
                  <button className="text-sm border border-brand-red text-brand-red px-4 py-2 rounded-lg hover:bg-brand-red hover:text-white transition">Add New</button>
                </h2>
                <div className="space-y-4">
                  {SERVICES.map(s => (
                    <div key={s.id} className="bg-brand-gray p-6 rounded-xl border border-white/10 flex flex-col md:flex-row gap-4 justify-between items-center">
                      <div className="flex items-center gap-6">
                        <div className="w-16 h-16 bg-black rounded-xl flex items-center justify-center text-brand-red shrink-0 border border-brand-red/20">{s.icon}</div>
                        <div>
                           <h4 className="font-bold text-lg">{s.name}</h4>
                           <p className="text-white/50 text-sm max-w-sm truncate">{s.description}</p>
                        </div>
                      </div>
                      <div className="flex gap-2 w-full md:w-auto">
                        <button className="flex-1 md:flex-none bg-white/10 px-4 py-2 rounded-lg font-bold hover:bg-white/20 text-sm">Edit Plan</button>
                        <button className="flex-1 md:flex-none bg-red-500/10 text-red-500 px-4 py-2 rounded-lg font-bold hover:bg-red-500 hover:text-white text-sm">Remove</button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
            
            {adminTab === 'gallery' && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <h2 className="font-display text-3xl mb-8 flex justify-between items-center border-b border-white/10 pb-4">
                  Gallery Media
                  <button className="text-sm bg-brand-red text-white px-4 py-2 rounded-lg hover:bg-red-600 transition shadow-glow-red flex items-center gap-2">Upload Media</button>
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                   {[
                     "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04",
                     "https://images.unsplash.com/photo-1516280440503-6c84c4c23c72",
                     "https://images.unsplash.com/photo-1621360841013-c76831f13b63",
                     "https://images.unsplash.com/photo-1520166012956-addbc4e3eb1b",
                     "https://images.unsplash.com/photo-1579684385127-1ef15d508118"
                   ].map((img, i) => (
                     <div key={i} className="group relative aspect-square bg-black rounded-xl overflow-hidden border border-white/10">
                       <img src={`${img}?q=50&w=400`} className="w-full h-full object-cover" />
                       <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                         <button className="p-2 bg-white/20 rounded-lg hover:bg-brand-red"><LogOut size={16} className="rotate-90" /></button>
                         <button className="p-2 bg-red-500/50 text-white rounded-lg hover:bg-red-500"><X size={16} /></button>
                       </div>
                     </div>
                   ))}
                </div>
              </motion.div>
            )}
            
            {adminTab === 'settings' && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="max-w-2xl">
                <h2 className="font-display text-3xl mb-8 border-b border-white/10 pb-4">Website Settings</h2>
                
                <div className="bg-brand-gray p-6 rounded-xl border border-white/10 mb-6">
                  <h3 className="text-xl mb-4 text-white/80 font-display">Theme Color</h3>
                  <div className="flex flex-wrap gap-4 items-center">
                    {['#ff003c', '#00ffd5', '#ffaa00', '#b800ff', '#ffffff'].map(c => (
                      <button 
                        key={c}
                        onClick={() => setThemeColor(c)}
                        className={`w-12 h-12 rounded-full border-2 transition-transform ${themeColor === c ? 'scale-110 border-white' : 'border-transparent'}`}
                        style={{ backgroundColor: c, boxShadow: themeColor === c ? `0 0 15px ${c}` : 'none' }}
                      />
                    ))}
                    <div className="ml-auto flex items-center gap-2 mt-4 sm:mt-0 w-full sm:w-auto">
                       <span className="text-white/50 text-xs sm:text-sm uppercase tracking-widest">Custom:</span>
                       <input 
                         type="color" 
                         value={themeColor} 
                         onChange={(e) => setThemeColor(e.target.value)} 
                         className="bg-transparent border-none outline-none w-8 h-10 cursor-pointer" 
                       />
                       <input 
                         type="text" 
                         value={themeColor} 
                         onChange={(e) => setThemeColor(e.target.value)} 
                         className="bg-black border border-white/10 rounded px-3 py-2 w-24 text-center text-sm focus:border-brand-red outline-none hidden sm:block" 
                       />
                    </div>
                  </div>
                </div>
                
                <div className="bg-brand-gray p-6 rounded-xl border border-white/10 space-y-4">
                  <h3 className="text-xl mb-2 text-white/80 font-display">General Info</h3>
                  <div>
                    <label className="block text-xs uppercase text-white/50 mb-2 tracking-widest">Studio Name</label>
                    <input type="text" value={studioName} onChange={(e) => setStudioName(e.target.value)} className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-brand-red transition" />
                  </div>
                  <div>
                    <label className="block text-xs uppercase text-white/50 mb-2 tracking-widest">WhatsApp Number</label>
                    <input type="text" value={studioPhone} onChange={(e) => setStudioPhone(e.target.value)} className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-brand-red transition" />
                  </div>
                </div>

                <div className="bg-brand-gray p-6 rounded-xl border border-white/10 space-y-4 mb-6">
                  <h3 className="text-xl mb-2 text-white/80 font-display">Social Media Links</h3>
                  <div>
                    <label className="block text-xs uppercase text-white/50 mb-2 tracking-widest">Instagram URL</label>
                    <input type="text" value={socialInstagram} onChange={(e) => setSocialInstagram(e.target.value)} className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-brand-red transition" />
                  </div>
                  <div>
                    <label className="block text-xs uppercase text-white/50 mb-2 tracking-widest">YouTube URL</label>
                    <input type="text" value={socialYoutube} onChange={(e) => setSocialYoutube(e.target.value)} className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-brand-red transition" />
                  </div>
                  <div>
                    <label className="block text-xs uppercase text-white/50 mb-2 tracking-widest">Facebook URL</label>
                    <input type="text" value={socialFacebook} onChange={(e) => setSocialFacebook(e.target.value)} className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-brand-red transition" />
                  </div>
                </div>

                <button className="w-full sm:w-auto bg-brand-red text-white px-8 py-3 rounded-xl font-bold shadow-glow-red mt-4 uppercase tracking-widest hover:scale-105 transition-transform">
                  Save Changes
                </button>
              </motion.div>
            )}
         </div>
      </div>
    );
  }

  return (
    <div className="bg-brand-black min-h-screen">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-glass py-4 px-6 md:px-12 flex items-center justify-between">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-3">
          <Headphones className="text-brand-red animate-pulse" size={28} />
          <span className="font-display text-2xl font-bold tracking-widest text-glow-red uppercase whitespace-nowrap">
            Sadakchaap
          </span>
        </motion.div>

        <div className="hidden md:flex items-center gap-8 font-semibold text-sm uppercase tracking-widest text-white/70">
          {['Home', 'About', 'Services', 'Gallery', 'Contact'].map(link => (
            <a key={link} href={`#${link.toLowerCase()}`} className="hover:text-white transition-colors relative group">
              {link}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-brand-red transition-all group-hover:w-full shadow-glow-red" />
            </a>
          ))}
        </div>

        <div className="flex items-center gap-6">
          <button onClick={() => setAdminAuthOpen(true)} className="hidden md:block text-xs uppercase tracking-widest text-white/30 hover:text-white">
            Admin
          </button>
          
          {user ? (
            <div className="relative group flex items-center gap-2 cursor-pointer text-white/70 hover:text-white">
              <User size={20} />
              <div className="absolute top-10 right-0 bg-brand-gray border border-white/10 p-4 rounded-xl w-48 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none group-hover:pointer-events-auto">
                <p className="text-xs mb-2 truncate font-bold">{user.email}</p>
                <div className="border-t border-white/5 my-2" />
                <button onClick={logOut} className="text-brand-red font-bold text-sm flex items-center gap-2 w-full hover:bg-white/5 p-2 rounded">
                  <LogOut size={14}/> Log Out
                </button>
              </div>
            </div>
          ) : (
            <button onClick={signInWithGoogle} className="text-sm font-bold uppercase tracking-widest hover:text-brand-red transition-colors">
              Login
            </button>
          )}

          <button onClick={() => setIsBookingOpen(true)} className="hidden md:flex bg-brand-red text-white px-6 py-2 rounded-full font-bold uppercase text-sm items-center gap-2 shadow-glow-red hover:bg-red-600 transition-all">
            Book Now
          </button>
          <button className="md:hidden" onClick={() => setIsMenuOpen(true)}>
            <MenuIcon size={24} />
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 bg-brand-black z-[60] p-6 flex flex-col"
          >
            <div className="flex justify-between items-center mb-12">
              <span className="font-display text-2xl text-brand-red">Menu</span>
              <button onClick={() => setIsMenuOpen(false)}><X size={32}/></button>
            </div>
            <div className="flex flex-col gap-6 text-2xl font-display uppercase items-center">
               {['Home', 'About', 'Services', 'Gallery', 'Contact'].map(link => (
                  <a key={link} href={`#${link.toLowerCase()}`} onClick={() => setIsMenuOpen(false)} className="hover:text-brand-red transition-colors">
                    {link}
                  </a>
               ))}
               <button onClick={() => { setIsMenuOpen(false); setAdminAuthOpen(true); }} className="text-white/50 hover:text-brand-red transition-colors text-2xl font-display uppercase">
                 Admin Access
               </button>
               <button onClick={() => { setIsBookingOpen(true); setIsMenuOpen(false); }} className="mt-8 text-brand-red shadow-glow-red">
                 BOOK SESSION
               </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
        <motion.div style={{ opacity: heroOpacity, scale: heroScale }} className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-black/80 to-black/60 z-10" />
          <img 
            src="https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=1920" 
            alt="Studio Background" 
            className="w-full h-full object-cover"
          />
        </motion.div>
        
        <div className="relative z-20 text-center px-4 max-w-5xl">
          <motion.div initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }}>
            <h1 className="font-display text-5xl md:text-8xl lg:text-9xl font-bold uppercase mb-6 text-glow-red leading-none">
              {studioName.split(' ').map((word, i) => (
                <span key={i}>{word}<br/></span>
              ))}
            </h1>
            <div className="text-xl md:text-3xl text-white/80 font-light mb-12 tracking-widest uppercase">
              <TypewriterText text="Create Music That Hits Different." />
            </div>
            <div className="flex flex-col md:flex-row items-center justify-center gap-6">
              <button onClick={() => setIsBookingOpen(true)} className="bg-brand-red text-white px-10 py-4 rounded-full font-bold uppercase tracking-widest flex items-center gap-3 shadow-glow-red hover:scale-105 transition-transform">
                <Calendar size={20} /> Book Studio
              </button>
              <a href="#contact" className="border border-white/30 hover:border-white text-white px-10 py-4 rounded-full font-bold uppercase tracking-widest transition-colors flex items-center gap-3">
                <Phone size={20} /> Contact Now
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-32 px-6 md:px-12 border-t border-white/5 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-brand-red/5 via-brand-black to-brand-black pointer-events-none" />
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 items-center relative z-10">
          <motion.div initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
            <h2 className="font-display text-4xl md:text-6xl font-bold mb-6 text-glow-red">About Us</h2>
            <h3 className="text-2xl text-white/80 mb-6 uppercase tracking-widest">Premium Sound Experience</h3>
            <p className="text-white/60 leading-relaxed mb-6 font-light text-lg">
              Welcome to Sadakchaap Studio, founded by <span className="text-white font-bold">Jatin Martin</span>. 
              We are a state-of-the-art music and video production facility located in New Delhi. Our mission is to elevate your sound to industry standards.
            </p>
            <p className="text-white/60 leading-relaxed font-light text-lg">
              Whether you are recording your first demo or shooting a professional 4K music video, our creative environment provides the perfect vibe to create music that truly hits different.
            </p>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="relative aspect-square md:aspect-video rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
            <div className="absolute inset-0 bg-brand-red/20 mix-blend-overlay z-10" />
            <img src="https://images.unsplash.com/photo-1621360841013-c76831f13b63?q=80&w=800" alt="Mixing Console" className="w-full h-full object-cover" />
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-32 px-6 md:px-12 bg-brand-gray border-t border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="font-display text-4xl md:text-6xl font-bold mb-4 text-glow-red">Our Services</h2>
            <p className="text-white/50 uppercase tracking-widest">Everything you need under one roof</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICES.map((srv, i) => (
              <motion.div 
                key={srv.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -10 }}
                className="group bg-brand-black border border-white/10 rounded-2xl overflow-hidden relative"
              >
                <div className="h-48 overflow-hidden relative">
                  <div className="absolute inset-0 bg-black/50 group-hover:bg-transparent transition-colors z-10" />
                  <img src={srv.image} alt={srv.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute top-4 left-4 z-20 text-brand-red">
                    {srv.icon}
                  </div>
                </div>
                <div className="p-8">
                  <h3 className="text-2xl font-bold mb-4 uppercase tracking-wider">{srv.name}</h3>
                  <p className="text-white/50 font-light leading-relaxed mb-6">{srv.description}</p>
                  <button onClick={() => { setBService(srv.name); setIsBookingOpen(true); }} className="text-brand-red font-bold uppercase tracking-widest flex items-center gap-2 hover:text-white transition-colors group-hover:shadow-glow-red">
                    Book This <ChevronRight size={18} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      {/* Shortened for brevity, representing a high-end feel */}
      <section id="gallery" className="py-32 px-6 md:px-12 border-t border-white/5">
         <div className="max-w-7xl mx-auto">
           <div className="flex justify-between items-end mb-16">
             <div>
               <h2 className="font-display text-4xl md:text-6xl font-bold text-glow-red mb-4">Gallery</h2>
               <p className="text-white/50 uppercase tracking-widest">Peek inside the studio</p>
             </div>
             <div className="hidden md:flex gap-4">
               <button className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:border-brand-red hover:text-brand-red transition"><ChevronRight size={24} className="rotate-180" /></button>
               <button className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:border-brand-red hover:text-brand-red transition"><ChevronRight size={24} /></button>
             </div>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04",
                "https://images.unsplash.com/photo-1516280440503-6c84c4c23c72",
                "https://images.unsplash.com/photo-1621360841013-c76831f13b63",
                "https://images.unsplash.com/photo-1520166012956-addbc4e3eb1b"
              ].map((img, i) => (
                <motion.div 
                  key={i} 
                  whileHover={{ scale: 0.95 }}
                  className={`relative rounded-xl overflow-hidden border border-white/5 cursor-pointer ${i === 0 || i === 3 ? 'md:col-span-2 aspect-video' : 'aspect-square'}`}
                >
                  <img src={`${img}?q=80&w=800`} className="w-full h-full object-cover hover:scale-110 transition-transform duration-700" alt="Gallery" />
                  <div className="absolute inset-0 bg-brand-red/0 hover:bg-brand-red/20 transition-colors flex items-center justify-center">
                     <Play className="opacity-0 hover:opacity-100 text-white drop-shadow-[0_0_10px_rgba(255,0,60,1)]" size={48} />
                  </div>
                </motion.div>
              ))}
           </div>
         </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-32 px-6 md:px-12 bg-brand-gray border-t border-white/5">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div>
            <h2 className="font-display text-4xl md:text-6xl font-bold mb-8 text-glow-red">Connect</h2>
            <p className="text-white/60 mb-12 text-lg">Ready to make a hit? Drop by our studio or hit us up on WhatsApp to lock in your session.</p>
            
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-brand-black border border-brand-red/50 flex items-center justify-center text-brand-red shadow-glow-red flex-shrink-0">
                  <MapPin size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-bold uppercase tracking-widest mb-1">Location</h4>
                  <p className="text-white/50">Rz-2072 Gali no. 28<br/>Tughlakabad Extension<br/>New Delhi-110019</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-brand-black border border-brand-red/50 flex items-center justify-center text-brand-red shadow-glow-red flex-shrink-0">
                  <Phone size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-bold uppercase tracking-widest mb-1">Call / WhatsApp</h4>
                  <a href={`tel:${studioPhone}`} className="text-white/50 hover:text-white block mb-1">{studioPhone}</a>
                  <a href={`https://wa.me/91${studioPhone}`} target="_blank" rel="noreferrer" className="text-brand-red font-bold hover:underline">Message on WhatsApp</a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-brand-black border border-brand-red/50 flex items-center justify-center text-brand-red shadow-glow-red flex-shrink-0">
                  <User size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-bold uppercase tracking-widest mb-1">Owner</h4>
                  <p className="text-white/50">Jatin Martin</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="h-96 rounded-2xl overflow-hidden border border-white/10 pointer-events-none">
            {/* Simple Map Placeholder */}
            <div className="w-full h-full bg-black flex items-center justify-center opacity-50 relative">
               <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=800" className="absolute inset-0 w-full h-full object-cover opacity-30" alt="Map" />
               <div className="relative text-center">
                 <div className="w-16 h-16 bg-brand-red rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce shadow-glow-red">
                   <MapPin size={24} />
                 </div>
                 <h3 className="font-display text-2xl font-bold">New Delhi</h3>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/10 text-center">
         <div className="flex justify-center gap-6 mb-8">
            {socialInstagram && <a href={socialInstagram} target="_blank" rel="noreferrer" className="text-white/40 hover:text-brand-red transition"><Instagram size={24} /></a>}
            {socialYoutube && <a href={socialYoutube} target="_blank" rel="noreferrer" className="text-white/40 hover:text-brand-red transition"><Youtube size={24} /></a>}
            {socialFacebook && <a href={socialFacebook} target="_blank" rel="noreferrer" className="text-white/40 hover:text-brand-red transition"><Facebook size={24} /></a>}
            <a href={`https://wa.me/91${studioPhone}`} className="text-white/40 hover:text-brand-red transition"><Phone size={24} /></a>
         </div>
         <p className="text-white/30 text-sm font-mono tracking-widest uppercase">
           © {new Date().getFullYear()} {studioName} by Jatin Martin. All rights reserved.
         </p>
      </footer>

      {/* Admin Login Modal */}
      <AnimatePresence>
        {adminAuthOpen && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4"
          >
             <motion.div 
               initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }}
               className="bg-brand-gray border border-brand-red p-8 rounded-2xl max-w-sm w-full shadow-glow-red relative"
             >
               <button 
                 onClick={() => setAdminAuthOpen(false)} 
                 className="absolute top-4 right-4 text-white/50 hover:text-white p-2"
               >
                 <X size={20}/>
               </button>
               <div className="mb-8 text-center">
                 <h3 className="font-display text-3xl text-glow-red text-brand-red tracking-widest uppercase">Admin Login</h3>
                 <p className="text-white/50 text-sm mt-2">Enter credentials to proceed</p>
               </div>
               <form onSubmit={handleAdminLogin}>
                 <input 
                   type="password" 
                   value={adminPwd} 
                   onChange={e => setAdminPwd(e.target.value)}
                   className="w-full bg-black border border-white/10 rounded-xl px-4 py-4 mb-6 focus:outline-none focus:border-brand-red tracking-widest text-center text-lg"
                   placeholder="Enter Password" 
                   autoFocus
                 />
                 <button type="submit" className="w-full bg-brand-red text-white py-4 rounded-xl font-bold uppercase tracking-widest hover:scale-105 transition-transform shadow-glow-red">
                   Access Control
                 </button>
               </form>
             </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Booking Form Modal */}
      <AnimatePresence>
        {isBookingOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100]" onClick={() => setIsBookingOpen(false)} />
            <motion.div 
              initial={{ opacity: 0, y: 50, scale: 0.9 }} 
              animate={{ opacity: 1, y: 0, scale: 1 }} 
              exit={{ opacity: 0, y: 20, scale: 0.9 }} 
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-lg bg-brand-gray border border-white/10 p-8 rounded-2xl z-[110] shadow-2xl"
            >
              <div className="flex justify-between items-center mb-8">
                <h3 className="font-display text-3xl font-bold text-glow-red">Book Studio</h3>
                <button onClick={() => setIsBookingOpen(false)} className="text-white/50 hover:text-white"><X size={24} /></button>
              </div>

              {!user && (
                 <div className="mb-6 p-4 bg-brand-red/10 border border-brand-red/30 rounded-xl text-center">
                    <p className="text-sm mb-4">Please log in to save your bookings and manage sessions.</p>
                    <button onClick={signInWithGoogle} className="bg-brand-red text-white px-6 py-2 rounded-full text-sm font-bold shadow-glow-red w-full">Log In with Google</button>
                 </div>
              )}

              <form onSubmit={handleBookSession} className="space-y-6">
                <div>
                  <label className="block text-xs uppercase tracking-widest text-white/50 mb-2">Name</label>
                  <input required type="text" value={bName} onChange={e => setBName(e.target.value)} className="w-full bg-brand-black border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-brand-red transition" placeholder="Your Name" />
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-widest text-white/50 mb-2">WhatsApp Number</label>
                  <input required type="tel" value={bPhone} onChange={e => setBPhone(e.target.value)} className="w-full bg-brand-black border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-brand-red transition" placeholder="+91 0000000000" />
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-widest text-white/50 mb-2">Select Service</label>
                  <select value={bService} onChange={e => setBService(e.target.value)} className="w-full bg-brand-black border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-brand-red transition appearance-none">
                    {SERVICES.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                  </select>
                </div>

                <div className="pt-4 border-t border-white/5 flex gap-4">
                  <button type="submit" className="flex-1 bg-brand-red text-white py-4 rounded-xl font-bold uppercase tracking-widest shadow-glow-red hover:bg-red-600 transition">
                    Submit Request
                  </button>
                </div>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>

    </div>
  );
}
